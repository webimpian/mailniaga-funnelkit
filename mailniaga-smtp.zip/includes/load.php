<?php
/**
 * Mailniaga WP Connector.
 *
 * @author  Web Impian
 * @license GPLv3
 *
 * @see     https://mailniaga.com
 */

defined('ABSPATH') || exit;

require_once __DIR__.'/vendor/autoload.php';